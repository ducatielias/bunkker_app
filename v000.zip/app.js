// app.js

document.addEventListener('DOMContentLoaded', () => {

  // 🔹 ESTADO GLOBAL DEL BUSCADOR Y MODO SECRETO
  const searchInput = document.getElementById('searchInput');
  const searchClear = document.getElementById('searchClear');
  const searchOptions = document.getElementById('searchOptions');
  const searchEnginesList = document.getElementById('searchEnginesList');
  const mainContent = document.getElementById('mainContent');
  
  let currentQuery = '';
  let isSecretMode = false;
  localStorage.setItem('secretMode', 'false'); // Siempre iniciamos en modo normal

  function getValidHttpUrl(value) {
    if (typeof value !== 'string') return null;

    try {
      const url = new URL(value);
      return url.protocol === 'http:' || url.protocol === 'https:' ? url : null;
    } catch (e) {
      return null;
    }
  }

  function getValidSearchUrl(template, query = 'consulta') {
    if (typeof template !== 'string' || !template.includes('{q}')) return null;
    return getValidHttpUrl(template.replace('{q}', encodeURIComponent(query)));
  }

  // 🔹 FUNCIONES DE DATOS (ENLACES DINÁMICOS)
  function getRawLinks() {
    const saved = localStorage.getItem('customLinks');
    if (saved) { try { return JSON.parse(saved).categories || DEFAULT_LINKS; } catch (e) {} }
    return DEFAULT_LINKS;
  }

  function getRawSecretLinks() {
    const saved = localStorage.getItem('customSecretLinks');
    if (saved) { try { return JSON.parse(saved).categories || DEFAULT_SECRET_LINKS; } catch (e) {} }
    return DEFAULT_SECRET_LINKS;
  }

  // Te devuelve los enlaces normales o los secretos dependiendo de dónde estés
  function getCurrentLinks() {
    return isSecretMode ? getRawSecretLinks() : getRawLinks();
  }

  // Guarda en la base de datos correcta dependiendo de dónde estés
  function saveCurrentLinks(categories) {
    const key = isSecretMode ? 'customSecretLinks' : 'customLinks';
    localStorage.setItem(key, JSON.stringify({ version: 2, categories }));
    renderLinks();
  }

  // 🔹 FUNCIONES DE DATOS (BUSCADORES)
  function loadSearchEngines() {
    const saved = localStorage.getItem('customEngines');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return DEFAULT_ENGINES;
  }
  function saveSearchEngines(engines) {
    localStorage.setItem('customEngines', JSON.stringify(engines));
    updateSearchUI(); 
    renderSearchEnginesEditor(); 
  }

  // 🔹 COLAPSAR/EXPANDIR
  const DYNAMIC_COLLAPSE_STATES_KEY = 'collapsedCategoryStatesV2';
  const STATIC_CATEGORY_IDS = new Set(['widget_aemet', 'ajustes']);

  function serializeCategoryName(categoryName) {
    return Array.from(
      categoryName,
      character => character.codePointAt(0).toString(16).padStart(6, '0')
    ).join('-');
  }

  function getDynamicCategoryId(categoryName, secret = isSecretMode) {
    const namespace = secret ? 'secret' : 'normal';
    return `links_${namespace}_${serializeCategoryName(categoryName)}`;
  }

  function isDynamicCategoryId(categoryId) {
    return categoryId.startsWith('links_normal_') || categoryId.startsWith('links_secret_');
  }

  function getDynamicCollapseStates() {
    const saved = localStorage.getItem(DYNAMIC_COLLAPSE_STATES_KEY);
    if (!saved) return {};

    try {
      const states = JSON.parse(saved);
      return states !== null && typeof states === 'object' && !Array.isArray(states) ? states : {};
    } catch (e) {
      return {};
    }
  }

  function saveDynamicCollapseState(categoryId, collapsed) {
    const states = getDynamicCollapseStates();
    states[categoryId] = collapsed ? 'true' : 'false';
    localStorage.setItem(DYNAMIC_COLLAPSE_STATES_KEY, JSON.stringify(states));
  }

  function getLegacyCategoryId(categoryName) {
    return categoryName.replace(/\s+/g, '_');
  }

  function canMigrateLegacyCollapseState(categoryName) {
    const legacyCategoryId = getLegacyCategoryId(categoryName);
    if (STATIC_CATEGORY_IDS.has(legacyCategoryId)) return false;

    const matchingNames = [
      ...Object.keys(getRawLinks()),
      ...Object.keys(getRawSecretLinks())
    ].filter(name => getLegacyCategoryId(name) === legacyCategoryId);

    return matchingNames.length === 1;
  }

  function getDynamicCollapseState(categoryName, categoryId) {
    const states = getDynamicCollapseStates();
    if (Object.prototype.hasOwnProperty.call(states, categoryId)) {
      return states[categoryId];
    }

    if (!canMigrateLegacyCollapseState(categoryName)) return null;

    const legacyState = localStorage.getItem(`collapsed_${getLegacyCategoryId(categoryName)}`);
    if (legacyState === null) return null;

    saveDynamicCollapseState(categoryId, legacyState === 'true');
    return legacyState;
  }

  function saveCollapseState(categoryId, collapsed) {
    if (isDynamicCategoryId(categoryId)) {
      saveDynamicCollapseState(categoryId, collapsed);
      return;
    }

    localStorage.setItem(`collapsed_${categoryId}`, collapsed ? 'true' : 'false');
  }

  window.toggleCategory = (catId) => {
    const card = document.getElementById(`cat_${catId}`);
    const chevron = document.getElementById(`chev_${catId}`);
    if (!card) return;
    
    if (card.style.display === 'none') {
      card.style.display = 'block';
      if (chevron) chevron.classList.remove('collapsed');
      saveCollapseState(catId, false);
    } else {
      card.style.display = 'none';
      if (chevron) chevron.classList.add('collapsed');
      saveCollapseState(catId, true);
    }
  };

  function applyCollapseState(catId, defaultCollapsed = false, stored = localStorage.getItem(`collapsed_${catId}`)) {
    const isCollapsed = stored !== null ? stored === 'true' : defaultCollapsed;
    
    if (isCollapsed) {
      const card = document.getElementById(`cat_${catId}`);
      const chevron = document.getElementById(`chev_${catId}`);
      if (card) card.style.display = 'none';
      if (chevron) chevron.classList.add('collapsed');
      
      if (stored === null) saveCollapseState(catId, true);
    }
  }

  function applyDynamicCollapseState(categoryName, categoryId) {
    applyCollapseState(categoryId, false, getDynamicCollapseState(categoryName, categoryId));
  }

  // 🔹 RENDERIZADO Y CRUD DE ENLACES
  function renderLinks() {
    const categories = getCurrentLinks(); // Lee la base de datos que toque
    const container = document.getElementById('linksContainer');
    container.replaceChildren();

    Object.entries(categories).forEach(([catName, links]) => {
      const catId = getDynamicCategoryId(catName);

      const header = document.createElement('div');
      header.className = 'category-header';

      const titleWrapper = document.createElement('div');
      titleWrapper.className = 'category-title-wrapper';
      titleWrapper.addEventListener('click', () => window.toggleCategory(catId));

      const title = document.createElement('h2');
      title.className = 'section-title';
      title.textContent = catName;

      const chevron = document.createElement('span');
      chevron.className = 'chevron';
      chevron.id = `chev_${catId}`;
      chevron.textContent = '▼';

      titleWrapper.append(title, chevron);

      const addLinkButton = document.createElement('span');
      addLinkButton.style.cssText = 'font-size:22px; color:var(--blue-ios); cursor:pointer; padding: 0 5px;';
      addLinkButton.textContent = '＋';
      addLinkButton.addEventListener('click', () => window.addLink(catName));

      header.append(titleWrapper, addLinkButton);

      const card = document.createElement('div');
      card.className = 'ios-card';
      card.id = `cat_${catId}`;

      const grid = document.createElement('div');
      grid.className = 'app-grid';
      
      if (links.length === 0) {
        const emptyMessage = document.createElement('p');
        emptyMessage.style.cssText = 'color:var(--text-secondary); font-size:13px; grid-column: 1/-1;';
        emptyMessage.textContent = 'No hay enlaces.';
        grid.appendChild(emptyMessage);
      }

      links.forEach(link => {
        const linkUrl = getValidHttpUrl(link.url);
        const domain = linkUrl ? linkUrl.hostname : '';

        const wrapper = document.createElement('div');
        wrapper.className = 'app-icon-wrapper';

        const iconLink = document.createElement('a');
        iconLink.href = linkUrl ? linkUrl.href : '#';
        iconLink.target = '_blank';
        iconLink.className = 'app-icon';
        iconLink.title = link.title;

        if (linkUrl) {
          const icon = document.createElement('img');
          icon.src = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
          icon.addEventListener('error', () => {
            icon.style.display = 'none';
            iconLink.textContent = domain.charAt(0).toUpperCase();
            iconLink.style.color = '#fff';
            iconLink.style.fontSize = '24px';
            iconLink.style.background = '#8e8e93';
          });
          iconLink.appendChild(icon);
        } else {
          iconLink.textContent = '?';
          iconLink.style.color = '#fff';
          iconLink.style.fontSize = '24px';
          iconLink.style.background = '#8e8e93';
        }

        const label = document.createElement('span');
        label.className = 'app-label';
        label.textContent = link.title;
        label.addEventListener('click', () => window.editLink(catName, link.id));

        wrapper.append(iconLink, label);
        grid.appendChild(wrapper);
      });

      const deleteContainer = document.createElement('div');
      deleteContainer.style.cssText = 'margin-top: 15px; text-align:right;';

      const deleteButton = document.createElement('button');
      deleteButton.style.cssText = 'background:none; border:none; color:var(--red-ios); font-size:12px; cursor:pointer;';
      deleteButton.textContent = 'Eliminar sección';
      deleteButton.addEventListener('click', () => window.deleteCategory(catName));
      deleteContainer.appendChild(deleteButton);

      card.append(grid, deleteContainer);
      container.append(header, card);
    });

    Object.keys(categories).forEach(catName => {
      applyDynamicCollapseState(catName, getDynamicCategoryId(catName));
    });
  }

  window.addLink = (cat) => {
    const title = prompt(`Título en "${cat}":`, '');
    if (!title) return;
    const url = prompt(`URL (ej: https://...):`, 'https://');
    if (!getValidHttpUrl(url)) return alert('URL inválida.');
    
    const c = getCurrentLinks(); // Guarda donde toque
    c[cat].push({ id: crypto.randomUUID(), title, url });
    saveCurrentLinks(c);
  };
  
  window.editLink = (cat, id) => {
    const c = getCurrentLinks();
    const link = c[cat].find(l => l.id === id);
    if(!link) return;
    const action = confirm(`¿Quieres editar "${link.title}"?\n\n[Aceptar] = Editar\n[Cancelar] = Eliminar`);
    if (action) {
      const t = prompt('Nuevo título:', link.title);
      const u = prompt('Nueva URL:', link.url);
      if (t && u) {
        if (!getValidHttpUrl(u)) return alert('URL inválida.');
        link.title = t;
        link.url = u;
        saveCurrentLinks(c);
      }
    } else {
      if(confirm('¿Seguro que quieres borrar este enlace?')) {
        c[cat] = c[cat].filter(l => l.id !== id);
        saveCurrentLinks(c);
      }
    }
  };

  window.addCategory = () => {
    const cat = prompt('Nombre de la nueva sección:');
    if(!cat) return;
    const c = getCurrentLinks();
    if(c[cat]) return alert('Ya existe.');
    c[cat] = [];
    saveCurrentLinks(c);
  };

  window.deleteCategory = (cat) => {
    if(!confirm(`¿Borrar la sección "${cat}" y todos sus enlaces?`)) return;
    const c = getCurrentLinks();
    delete c[cat];
    saveCurrentLinks(c);
  };


  // 🔹 BUSCADORES EDITOR
  function renderSearchEnginesEditor() {
    const engines = loadSearchEngines();
    const visibleEngines = engines.filter(e => isSecretMode ? true : !e.secret);
    
    const listEl = document.getElementById('enginesEditorList');
    listEl.replaceChildren();

    visibleEngines.forEach(eng => {
      const iconUrl = `https://www.google.com/s2/favicons?domain=${eng.domain}&sz=32`;
      const isEnabled = eng.enabled !== false; 
      const textStyle = isEnabled ? '' : 'text-decoration: line-through; color: var(--text-secondary);';

      const item = document.createElement('div');
      item.className = 'engine-list-item';

      const info = document.createElement('div');
      info.className = 'engine-info';

      const enabledInput = document.createElement('input');
      enabledInput.type = 'checkbox';
      enabledInput.checked = isEnabled;
      enabledInput.title = 'Activar/Desactivar';
      enabledInput.addEventListener('change', () => window.toggleEngineEnabled(eng.id));

      const icon = document.createElement('img');
      icon.src = iconUrl;
      icon.addEventListener('error', () => { icon.style.display = 'none'; });

      const name = document.createElement('span');
      name.style.cssText = `font-size: 14px; ${textStyle}`;
      name.textContent = eng.name;

      info.append(enabledInput, icon, name);

      if (eng.secret) {
        const secretBadge = document.createElement('span');
        secretBadge.className = 'badge-secret';
        secretBadge.textContent = 'Secreto';
        info.appendChild(secretBadge);
      }

      const actions = document.createElement('div');
      actions.className = 'engine-actions';

      const editButton = document.createElement('button');
      editButton.title = 'Editar';
      editButton.textContent = '✏️';
      editButton.addEventListener('click', () => window.editSearchEngine(eng.id));

      const deleteButton = document.createElement('button');
      deleteButton.title = 'Eliminar';
      deleteButton.textContent = '🗑️';
      deleteButton.addEventListener('click', () => window.deleteSearchEngine(eng.id));

      actions.append(editButton, deleteButton);
      item.append(info, actions);
      listEl.appendChild(item);
    });
    
    if(visibleEngines.length === 0) {
      const emptyMessage = document.createElement('p');
      emptyMessage.style.cssText = 'font-size:13px; color:var(--text-secondary); padding-bottom: 10px;';
      emptyMessage.textContent = 'No hay buscadores visibles.';
      listEl.appendChild(emptyMessage);
    }
  }

  window.toggleEngineEnabled = (id) => {
    const engines = loadSearchEngines();
    const eng = engines.find(e => e.id === id);
    if (eng) {
      eng.enabled = eng.enabled === false ? true : false;
      saveSearchEngines(engines);
    }
  };

  window.addSearchEngine = () => {
    const name = prompt('Nombre del buscador (ej: Wikipedia):');
    if (!name) return;
    const url = prompt('URL de búsqueda (Asegúrate de incluir {q} donde va el texto a buscar):', 'https://');
    const searchUrl = getValidSearchUrl(url);
    if (!searchUrl) return alert('URL inválida. Debe incluir {q} y usar http o https.');
    const domain = searchUrl.hostname;
    
    const isSecret = confirm('¿Quieres que este buscador solo aparezca en el Modo Secreto? \n[Aceptar] = Sí \n[Cancelar] = No');
    
    const engines = loadSearchEngines();
    engines.push({ id: crypto.randomUUID(), name, url, domain, secret: isSecret, enabled: true });
    saveSearchEngines(engines);
  };

  window.editSearchEngine = (id) => {
    const engines = loadSearchEngines();
    const eng = engines.find(e => e.id === id);
    if(!eng) return;
    
    const newName = prompt('Editar Nombre:', eng.name);
    if (!newName) return;
    const newUrl = prompt('Editar URL (Debe contener {q}):', eng.url);
    const searchUrl = getValidSearchUrl(newUrl);
    if (!searchUrl) return alert('URL inválida. Debe incluir {q} y usar http o https.');
    const newSecret = confirm('¿Debe ser Secreto? \n[Aceptar] = Sí \n[Cancelar] = No');
    
    eng.domain = searchUrl.hostname;
    eng.name = newName; eng.url = newUrl; eng.secret = newSecret;
    saveSearchEngines(engines);
  };

  window.deleteSearchEngine = (id) => {
    if (!confirm('¿Eliminar este buscador?')) return;
    let engines = loadSearchEngines();
    engines = engines.filter(e => e.id !== id);
    saveSearchEngines(engines);
  };


  // 🔹 INTERFAZ DEL BUSCADOR UNIFICADO
  function openSearchUrl(template) {
    const url = getValidSearchUrl(template, currentQuery);
    if (url) window.open(url.href, '_blank');
  }

  function updateSearchUI() {
    if (isSecretMode) {
      searchInput.classList.add('secret-mode');
      searchInput.placeholder = 'Modo Secreto 🔓';
    } else {
      searchInput.classList.remove('secret-mode');
      searchInput.placeholder = 'Buscar...';
    }
    buildSearchList();
    renderSearchEnginesEditor(); 
    
    // Al cambiar de modo, renderizamos los enlaces (para cambiar entre normales y secretos)
    renderLinks(); 
  }

  function buildSearchList() {
    const engines = loadSearchEngines();
    const visibleEngines = engines.filter(e => {
      if (e.enabled === false) return false;
      return isSecretMode ? e.secret : !e.secret;
    });

    searchEnginesList.replaceChildren();

    visibleEngines.forEach(eng => {
      const item = document.createElement('div');
      item.className = `ios-list-item${isSecretMode ? ' secret-item' : ''}`;
      item.dataset.url = eng.url;

      const icon = document.createElement('img');
      icon.src = `https://www.google.com/s2/favicons?domain=${eng.domain}&sz=32`;

      const text = document.createElement('span');
      text.append('Buscar en ');

      const name = document.createElement('b');
      name.textContent = eng.name;
      text.appendChild(name);

      item.append(icon, text);
      item.addEventListener('click', () => {
        if (!currentQuery) return;
        openSearchUrl(item.dataset.url);
      });
      searchEnginesList.appendChild(item);
    });
  }

  searchInput.addEventListener('input', (e) => {
    const val = e.target.value.trim();
    
    if (val.toLowerCase() === 'xxx') {
      isSecretMode = !isSecretMode;
      localStorage.setItem('secretMode', isSecretMode);
      updateSearchUI();
      searchInput.value = '';
      closeSearch();
      return;
    }

    currentQuery = val;
    
    if (currentQuery.length > 0) {
      searchClear.style.display = 'flex';
      searchOptions.classList.add('show');
      mainContent.style.opacity = '0.3'; 
      mainContent.style.pointerEvents = 'none';
    } else {
      closeSearch();
    }
  });

  searchInput.addEventListener('keydown', (e) => {
    if(e.key === 'Enter' && currentQuery) {
      const engines = loadSearchEngines();
      const firstEngine = engines.find(e => {
        if(e.enabled === false) return false;
        return isSecretMode ? e.secret : !e.secret;
      });
      if (firstEngine) {
        openSearchUrl(firstEngine.url);
      }
    }
  });

  searchClear.addEventListener('click', closeSearch);

  function closeSearch() {
    searchInput.value = '';
    currentQuery = '';
    searchClear.style.display = 'none';
    searchOptions.classList.remove('show');
    mainContent.style.opacity = '1';
    mainContent.style.pointerEvents = 'auto';
    searchInput.blur();
  }

  // 🔹 AEMET
  function initAemet() {
    applyCollapseState('widget_aemet'); 
    
    const feedUrl = 'https://www.aemet.es/documentos_d/eltiempo/prediccion/avisos/rss/CAP_AFAP7703_ATOM.xml';
    const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feedUrl)}&_=${new Date().getTime()}`;
    const list = document.getElementById('avisos-lista');

    fetch(apiUrl)
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => {
        if (data.status !== 'ok') throw new Error('API RSS Error');
        const items = data.items.filter(i => 
          !i.title.toLowerCase().includes('estado completo') && 
          !i.title.toLowerCase().includes('sin avisos')
        );
        
        if (!items.length) { 
          const noWarnings = document.createElement('div');
          noWarnings.style.padding = '10px 0';
          noWarnings.textContent = '✅ No hay avisos meteorológicos activos ahora mismo.';
          list.replaceChildren(noWarnings);
          return; 
        }

        list.replaceChildren();
        items.forEach(item => {
          let cleanTitle = item.title.replace(/^Aviso\.\s*Nivel\s+\w+\.\s*/i, '');
          let desc = item.description ? item.description.replace(/<[^>]*>/g, '').substring(0, 80) + '...' : '';
          const level = /rojo/i.test(item.title) ? 'nivel-rojo' : /naranja/i.test(item.title) ? 'nivel-naranja' : 'nivel-amarillo';

          const warning = document.createElement('div');
          warning.className = 'aviso';

          const warningTitle = document.createElement('div');
          warningTitle.className = level;
          warningTitle.textContent = `⚠️ ${cleanTitle}`;

          const warningDescription = document.createElement('div');
          warningDescription.style.cssText = 'font-size:13px; color:var(--text-secondary); margin-top:4px;';
          warningDescription.textContent = desc;

          warning.append(warningTitle, warningDescription);
          list.appendChild(warning);
        });
      })
      .catch(() => { 
        const errorMessage = document.createElement('div');
        errorMessage.style.padding = '10px 0';
        errorMessage.textContent = '⚠️ No se ha podido cargar la información de AEMET.';
        list.replaceChildren(errorMessage);
      });
  }

  // 🔹 MENÚS AJUSTES EXPORTAR / IMPORTAR
  document.getElementById('toggleEnginesBtn').addEventListener('click', () => {
    const sec = document.getElementById('enginesSection');
    sec.style.display = sec.style.display === 'none' ? 'block' : 'none';
    document.getElementById('exportSection').style.display = 'none'; 
  });

  document.getElementById('toggleExportBtn').addEventListener('click', () => {
    const sec = document.getElementById('exportSection');
    sec.style.display = sec.style.display === 'none' ? 'block' : 'none';
    document.getElementById('enginesSection').style.display = 'none'; 
  });

  // Ahora exportamos tanto los normales como los secretos
  document.getElementById('exportBtn').addEventListener('click', () => {
    const exportData = { 
      version: 2, 
      categories: getRawLinks(), 
      secretCategories: getRawSecretLinks(),
      engines: loadSearchEngines() 
    };
    document.getElementById('dataTextarea').value = JSON.stringify(exportData);
    document.getElementById('importStatus').innerText = "✅ Código copiado en la caja de texto.";
  });

  const IMPORT_VALIDATION_ERROR = 'IMPORT_VALIDATION_ERROR';
  const IMPORT_ROLLBACK_ERROR = 'IMPORT_ROLLBACK_ERROR';

  function createImportError(code) {
    const error = new Error(code);
    error.code = code;
    return error;
  }

  function isDataObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function hasOwn(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  }

  function validateCategories(categories) {
    if (!isDataObject(categories)) throw createImportError(IMPORT_VALIDATION_ERROR);

    Object.values(categories).forEach(links => {
      if (!Array.isArray(links)) throw createImportError(IMPORT_VALIDATION_ERROR);

      links.forEach(link => {
        if (
          !isDataObject(link) ||
          typeof link.id !== 'string' ||
          typeof link.title !== 'string' ||
          !getValidHttpUrl(link.url)
        ) {
          throw createImportError(IMPORT_VALIDATION_ERROR);
        }
      });
    });
  }

  function validateEngines(engines) {
    if (!Array.isArray(engines)) throw createImportError(IMPORT_VALIDATION_ERROR);

    engines.forEach(engine => {
      if (
        !isDataObject(engine) ||
        typeof engine.id !== 'string' ||
        typeof engine.name !== 'string' ||
        !getValidSearchUrl(engine.url) ||
        typeof engine.domain !== 'string' ||
        (hasOwn(engine, 'secret') && typeof engine.secret !== 'boolean') ||
        (hasOwn(engine, 'enabled') && typeof engine.enabled !== 'boolean')
      ) {
        throw createImportError(IMPORT_VALIDATION_ERROR);
      }
    });
  }

  function prepareImport(json) {
    if (!isDataObject(json)) throw createImportError(IMPORT_VALIDATION_ERROR);

    const writes = [];

    if (hasOwn(json, 'categories')) {
      validateCategories(json.categories);
      writes.push({
        key: 'customLinks',
        value: JSON.stringify({ version: 2, categories: json.categories })
      });
    }

    if (hasOwn(json, 'secretCategories')) {
      validateCategories(json.secretCategories);
      writes.push({
        key: 'customSecretLinks',
        value: JSON.stringify({ version: 2, categories: json.secretCategories })
      });
    }

    if (hasOwn(json, 'engines')) {
      validateEngines(json.engines);
      writes.push({ key: 'customEngines', value: JSON.stringify(json.engines) });
    }

    return writes;
  }

  function restoreStorageValue(key, value) {
    if (value === null) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, value);
    }
  }

  function commitImport(writes) {
    const previousValues = new Map(
      writes.map(write => [write.key, localStorage.getItem(write.key)])
    );
    const completedWrites = [];

    try {
      writes.forEach(write => {
        localStorage.setItem(write.key, write.value);
        completedWrites.push(write.key);
      });
    } catch (error) {
      let rollbackFailed = false;

      completedWrites.reverse().forEach(key => {
        try {
          restoreStorageValue(key, previousValues.get(key));
        } catch (rollbackError) {
          rollbackFailed = true;
        }
      });

      if (rollbackFailed) throw createImportError(IMPORT_ROLLBACK_ERROR);
      throw error;
    }
  }

  document.getElementById('importBtn').addEventListener('click', () => {
    const val = document.getElementById('dataTextarea').value.trim();
    let writes;

    try {
      const json = JSON.parse(val);
      writes = prepareImport(json);
    } catch(e) {
      document.getElementById('importStatus').innerText = "❌ Formato incorrecto.";
      return;
    }

    try {
      commitImport(writes);
    } catch (e) {
      document.getElementById('importStatus').innerText = e.code === IMPORT_ROLLBACK_ERROR
        ? "⚠️ No se ha podido restaurar completamente la configuración anterior; el estado puede ser incierto."
        : "❌ No se ha podido guardar la importación. La configuración anterior se ha conservado.";
      return;
    }

    updateSearchUI();
    document.getElementById('importStatus').innerText = "✅ Importado con éxito.";
  });

  // 🔹 INICIALIZACIÓN
  applyCollapseState('ajustes', true); 
  updateSearchUI(); // Esto inicializará la interfaz y cargará los enlaces correspondientes
  initAemet();
});
